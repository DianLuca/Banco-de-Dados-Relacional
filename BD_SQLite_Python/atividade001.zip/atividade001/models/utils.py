# Arquivo para validação de informações

def funcao_teste_utils():
    print('módulo utils.')